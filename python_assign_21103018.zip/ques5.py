# PART A
print('A.')
list = ['Red','Green','White','Black','Pink','Yellow']
print(list)  #input given
list.remove('Black')
print(list)  #output

#PART B
print( )
print('PART B')
list2 = ['Red','Green','White','Black','Pink','Yellow']
print(list2)
list2[3]='Purple'  #replacing black with purple using n-1 term operation
list2[4]='Purple'

print(list2)
