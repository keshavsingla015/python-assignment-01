
a = int(input('enter first number: '))
b = int(input('enter second number: '))
c = int(input('enter third number: '))

average = str(a + b + c / 3)

print(average)
